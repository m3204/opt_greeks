from .black_scholes import BlackScholes

"""
Module for calculating option greeks.
"""

__version__ = '0.0.1'

__all__ = ['BlackScholes']

