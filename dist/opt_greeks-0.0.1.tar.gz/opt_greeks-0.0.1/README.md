# opt_greeks
opt_greeks is a Python package for calculating option Greeks and implied volatility using the Black-Scholes model. It provides functions for computing option prices, deltas, thetas, vegas, and rhos, as well as implied volatility from option prices.
